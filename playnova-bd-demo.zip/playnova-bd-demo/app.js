const games = [
  {name:"Nova Fortune", category:"Slots", symbol:"✦", theme:"purple", description:"A colorful, fictional slot-style interface for UI testing."},
  {name:"Golden Orbit", category:"Arcade", symbol:"☀", theme:"orange", description:"Try a simple pretend wheel animation. No prizes or cash value."},
  {name:"Gem Garden", category:"Puzzle", symbol:"◆", theme:"teal", description:"A bright gem-themed casual demo."},
  {name:"Lucky Lantern", category:"Slots", symbol:"✺", theme:"orange", description:"A lantern-themed visual demo."},
  {name:"Sky Dash", category:"Arcade", symbol:"➤", theme:"teal", description:"A fictional arcade game preview."},
  {name:"Royal Tiles", category:"Puzzle", symbol:"▦", theme:"purple", description:"A tile-themed puzzle preview."},
  {name:"Goal Pop", category:"Sports", symbol:"⚽", theme:"teal", description:"A sports-themed mini-game preview."},
  {name:"Star Match", category:"Puzzle", symbol:"★", theme:"orange", description:"Match stars in this pretend game preview."}
];
let balance = 1000;
let activity = [{title:"Demo account created", detail:"Starting demo credits", amount:1000, type:"plus", time:new Date()}];
let currentAction = "deposit";
let currentGame = "Nova Fortune";
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const money = n => "৳" + n.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(window.toastTimeout);window.toastTimeout=setTimeout(()=>el.classList.remove("show"),2500)}
function renderBalance(){$("#balance").textContent=money(balance)}
function renderGames(category="All"){
  const filtered=category==="All"?games:games.filter(g=>g.category===category);
  $("#gameCount").textContent=`${filtered.length} games`;
  $("#gameGrid").innerHTML=filtered.map(g=>`<article class="game-card ${g.theme}"><div class="game-art"><span class="game-symbol">${g.symbol}</span><span class="game-tag">${g.category.toUpperCase()}</span></div><h3>${g.name}</h3><p>${g.description}</p><button class="small-btn play-btn" data-game="${g.name}">Play demo</button></article>`).join("");
}
function renderActivity(){
  const el=$("#activityList");
  if(!activity.length){el.innerHTML='<p class="subtle">No demo activity yet.</p>';return}
  el.innerHTML=activity.map(a=>`<div class="activity-item"><div><b>${a.title}</b><small>${a.detail} · ${new Date(a.time).toLocaleString()}</small></div><span class="activity-value" style="color:${a.type==="plus"?"#15976e":"#d46b48"}">${a.type==="plus"?"+":"−"}${money(a.amount)}</span></div>`).join("");
}
function showPage(page){
  $$(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
function openGame(name){
  const game=games.find(g=>g.name===name)||games[0];currentGame=game.name;
  $("#modalTitle").textContent=game.name;$("#modalDescription").textContent=game.description;$("#modalSymbol").textContent=game.symbol;
  $("#demoGameBox").textContent="✦  ★  ✦";
  $("#gameDialog").showModal();
}
function openAction(action){
  currentAction=action;
  const isDeposit=action==="deposit";
  $("#actionTitle").textContent=isDeposit?"Add demo credits":"Use demo credits";
  $("#actionDescription").textContent=isDeposit?"Add pretend credits to test the account interface. No payment is taken.":"Subtract pretend credits from your demo balance. This is not a real withdrawal.";
  $("#amountInput").value=isDeposit?100:Math.min(100,Math.max(1,Math.floor(balance)));
  $("#confirmAction").textContent=isDeposit?"Add demo credits":"Use demo credits";
  $("#actionDialog").showModal();
}
document.addEventListener("click",e=>{
  const play=e.target.closest(".play-btn");if(play){openGame(play.dataset.game);return}
  const page=e.target.closest("[data-page]");if(page){showPage(page.dataset.page);return}
  const cat=e.target.closest(".category");if(cat){$$(".category").forEach(c=>c.classList.toggle("active",c===cat));renderGames(cat.dataset.category);return}
  const action=e.target.closest("[data-action]");if(action){const a=action.dataset.action;if(a==="history"){showPage("activityPage");renderActivity()}else openAction(a);return}
});
$("#exploreBtn").addEventListener("click",()=>$("#allGames").scrollIntoView({behavior:"smooth"}));
$("#helpBtn").addEventListener("click",()=>$("#infoDialog").showModal());
$("#aboutBtn").addEventListener("click",()=>$("#infoDialog").showModal());
$("#infoClose").addEventListener("click",()=>$("#infoDialog").close());
$("#bonusBtn").addEventListener("click",()=>toast("Daily fun: this demo has no real rewards."));
$("#resetBtn").addEventListener("click",()=>{balance=1000;activity.unshift({title:"Demo balance reset",detail:"Balance restored to starting amount",amount:1000,type:"plus",time:new Date()});renderBalance();renderActivity();toast("Demo balance reset to ৳1,000.00")});
$("#confirmAction").addEventListener("click",()=>{
  const amount=Number($("#amountInput").value);
  if(!Number.isFinite(amount)||amount<1||amount>10000){toast("Enter an amount between ৳1 and ৳10,000.");return}
  if(currentAction==="withdraw"&&amount>balance){toast("Not enough demo credits.");return}
  const plus=currentAction==="deposit";
  balance+=plus?amount:-amount;
  activity.unshift({title:plus?"Demo credits added":"Demo credits used",detail:"Local-only demo transaction",amount,type:plus?"plus":"minus",time:new Date()});
  renderBalance();renderActivity();$("#actionDialog").close();toast(plus?"Demo credits added. No payment was made.":"Demo credits used. No money was withdrawn.");
});
$("#tryAgainBtn").addEventListener("click",()=>{$("#demoGameBox").textContent=["✦  ★  ✦","●  ◆  ★","☀  ✦  ◆","★  ★  ✦"][Math.floor(Math.random()*4)];toast("Demo animation only — no cash prizes.")});
renderGames();renderBalance();renderActivity();